library(happy.hbrem)
for (chr in 1:5){
  datafile <- paste("chr",toString(chr),".MAGIC.data",sep="")
  allelefile <- paste("chr",toString(chr),".MAGIC.alleles",sep="")
  h <- happy(datafile,allelefile, generations=6,file.format="ped",phase = "unknown",haploid=TRUE)
  nmark <- length(h$marker) 
  pr <-hdesign(h, 1,model='additive')
  for (i in 2:(nmark-1)) pr <- rbind(pr,hdesign(h, i,model='additive'))
  outfile=paste("hdesign_MAGIC_chr",toString(chr),".csv",sep="")
  write.csv(pr, file = outfile, row.names = FALSE)
}